package com.milkman.pro;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.Locale;

/**
 * Web app ke reminders ko Android AlarmManager mein schedule karta hai,
 * taaki app band hone par bhi notification aaye.
 */
public class ReminderScheduler {
    static final String PREFS = "milk_native";
    private static final String KEY_REMINDERS = "reminders";
    private static final String KEY_CODES = "codes";
    static final String CHANNEL_ID = "milk_reminders";
    static final String TITLE = "\uD83D\uDD14 Milkman PRO Reminder";

    static int codeOf(String id) {
        return (id == null ? 0 : id.hashCode()) & 0x7fffffff;
    }

    static void saveReminders(Context c, String json) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_REMINDERS, json).apply();
    }

    private static JSONArray loadReminders(Context c) {
        String s = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_REMINDERS, "[]");
        try {
            return new JSONArray(s);
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    static JSONObject findReminder(Context c, String id) {
        JSONArray a = loadReminders(c);
        for (int i = 0; i < a.length(); i++) {
            JSONObject r = a.optJSONObject(i);
            if (r != null && id != null && id.equals(r.optString("id"))) return r;
        }
        return null;
    }

    private static PendingIntent alarmIntent(Context c, String id, int flags) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.setAction(AlarmReceiver.ACTION_FIRE);
        i.putExtra("id", id);
        return PendingIntent.getBroadcast(c, codeOf(id), i, flags | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Purane alarm hatao, naye reminders ke agle time par alarm lagao. */
    static synchronized void scheduleAll(Context c) {
        Context app = c.getApplicationContext();
        AlarmManager am = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        SharedPreferences sp = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        // 1) purane alarm cancel
        try {
            JSONArray old = new JSONArray(sp.getString(KEY_CODES, "[]"));
            // purane ids ka record rakhte hain, taaki delete kiye reminder ka alarm bhi hate
            for (int i = 0; i < old.length(); i++) {
                String id = old.optString(i);
                PendingIntent pi = alarmIntent(app, id, PendingIntent.FLAG_NO_CREATE);
                if (pi != null) {
                    am.cancel(pi);
                    pi.cancel();
                }
            }
        } catch (Exception ignored) {
        }

        // 2) naye alarm
        JSONArray ids = new JSONArray();
        long now = System.currentTimeMillis();
        JSONArray list = loadReminders(app);
        for (int i = 0; i < list.length(); i++) {
            JSONObject r = list.optJSONObject(i);
            if (r == null || !r.optBoolean("enabled", true)) continue;
            String id = r.optString("id", "");
            if (id.isEmpty()) continue;
            long when = nextFire(r, now);
            if (when < 0) continue;
            PendingIntent pi = alarmIntent(app, id, PendingIntent.FLAG_UPDATE_CURRENT);
            setAlarm(app, am, when, pi);
            ids.put(id);
        }
        sp.edit().putString(KEY_CODES, ids.toString()).apply();
    }

    /** Snooze: kuch minute baad dobara alarm. */
    static void scheduleSnooze(Context c, String id, String title, String body, int minutes) {
        Context app = c.getApplicationContext();
        AlarmManager am = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(app, AlarmReceiver.class);
        i.setAction(AlarmReceiver.ACTION_SNOOZE_FIRE);
        i.putExtra("id", id == null ? "" : id);
        i.putExtra("title", title);
        i.putExtra("body", body);
        PendingIntent pi = PendingIntent.getBroadcast(app, codeOf("snooze_" + id), i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        setAlarm(app, am, System.currentTimeMillis() + minutes * 60000L, pi);
    }

    /**
     * setAlarmClock() asli "alarm clock" jaisa hai: Doze / battery saver / Oppo ColorOS ki wajah se der nahi hoti,
     * aur exact-alarm permission ki zaroorat nahi padti. (Status bar mein chhota alarm icon dikhna normal hai.)
     */
    private static void setAlarm(Context c, AlarmManager am, long when, PendingIntent pi) {
        try {
            Intent show = new Intent(c, MainActivity.class)
                    .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent showPi = PendingIntent.getActivity(c, 9001, show,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(when, showPi), pi);
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        }
    }

    /** Web app ke nextFire() jaisa hi logic. Return: millis ya -1. */
    static long nextFire(JSONObject r, long nowMs) {
        String[] hm = r.optString("time", "").split(":");
        if (hm.length < 2) return -1;
        int h, m;
        try {
            h = Integer.parseInt(hm[0].trim());
            m = Integer.parseInt(hm[1].trim());
        } catch (NumberFormatException e) {
            return -1;
        }
        String type = r.optString("type", "custom");
        int day = r.optInt("day", 1);
        boolean once = "custom".equals(type) && "once".equals(r.optString("repeat", ""));
        String date = r.optString("date", "");

        for (int add = 0; add < 400; add++) {
            Calendar d = Calendar.getInstance();
            d.setTimeInMillis(nowMs);
            d.set(Calendar.HOUR_OF_DAY, h);
            d.set(Calendar.MINUTE, m);
            d.set(Calendar.SECOND, 0);
            d.set(Calendar.MILLISECOND, 0);
            d.add(Calendar.DAY_OF_MONTH, add);
            if (d.getTimeInMillis() <= nowMs) continue;
            if ("bill".equals(type)
                    && d.get(Calendar.DAY_OF_MONTH) != Math.min(day, d.getActualMaximum(Calendar.DAY_OF_MONTH))) continue;
            if (once) {
                String ds = String.format(Locale.US, "%04d-%02d-%02d",
                        d.get(Calendar.YEAR), d.get(Calendar.MONTH) + 1, d.get(Calendar.DAY_OF_MONTH));
                if (!ds.equals(date)) continue;
            }
            return d.getTimeInMillis();
        }
        return -1;
    }

    static String bodyFor(JSONObject r) {
        String type = r.optString("type", "custom");
        String cust = r.optString("cust", "");
        String who = cust.isEmpty() ? "" : " | Customer: " + cust;
        switch (type) {
            case "entry":
                return "Today's milk entry is pending! App kholke entry bharo." + who;
            case "payment":
                return "Pending payments check karo. App kholke dues dekho." + who;
            case "bill":
                return "Bill reminder: pichhle mahine ke bills banane ka time." + who;
            default:
                String label = r.optString("label", "");
                return (label.isEmpty() ? "Reminder" : label) + who;
        }
    }

    static void createChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Milkman reminders",
                    NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Daily entry, payment aur bill reminders");
            ch.enableVibration(true);
            ch.setVibrationPattern(new long[]{0, 300, 150, 300});
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(ch);
        }
    }

    static void notifyNow(Context c, String title, String body, int id) {
        createChannel(c);
        if (Build.VERSION.SDK_INT >= 33
                && ActivityCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(c, id, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder b = new NotificationCompat.Builder(c, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setAutoCancel(true)
                .setContentIntent(content);
        NotificationManagerCompat.from(c).notify(id, b.build());
    }
}
