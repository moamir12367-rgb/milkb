package com.milkman.pro;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import org.json.JSONObject;

public class AlarmReceiver extends BroadcastReceiver {
    static final String ACTION_FIRE = "com.milkman.pro.REMINDER_FIRE";
    static final String ACTION_SNOOZE_FIRE = "com.milkman.pro.SNOOZE_FIRE";

    @Override
    public void onReceive(Context context, Intent intent) {
        PendingResult pr = goAsync();
        try {
            String id = intent.getStringExtra("id");
            boolean snooze = ACTION_SNOOZE_FIRE.equals(intent.getAction());
            JSONObject r = ReminderScheduler.findReminder(context, id);

            String title = ReminderScheduler.TITLE;
            String body = null;
            if (r != null && r.optBoolean("enabled", true)) {
                body = ReminderScheduler.bodyFor(r);
            } else if (snooze && intent.getStringExtra("body") != null) {
                body = intent.getStringExtra("body");
                if (intent.getStringExtra("title") != null) title = intent.getStringExtra("title");
            }
            if (body != null) {
                try {
                    AlarmService.start(context, id == null ? "" : id, title, body);
                } catch (Exception e) {
                    // service start na ho paaye to kam se kam normal notification
                    ReminderScheduler.notifyNow(context, title, body, ReminderScheduler.codeOf(id));
                }
            }
        } finally {
            // exact alarm ek baar chalta hai, isliye agla time turant set karo
            ReminderScheduler.scheduleAll(context);
            pr.finish();
        }
    }
}
