MILKMAN PRO - ANDROID APP v1.4 (ALARM + LOGIN + PROFILE + SMS OTP)
==================================================================

- v1.4: (1) Alarm ab Android ke asli "alarm clock" tareeke (setAlarmClock) se lagta hai, taaki Oppo / ColorOS
  ya battery saver ki wajah se alarm 2-3 minute late na baje. Status bar mein chhota alarm icon dikhna
  normal hai, aur phone ki Clock app mein "next alarm" bhi dikhega.
  (2) Alarm screen naya: navy + orange premium look, bada time, date, dhadakta alarm icon, reminder ka card,
  STOP aur snooze ke gol buttons.
  Ye maine phone par test nahi kiya (Android SDK nahi tha); pehli baar build par error aaye to text bhej do.
- Purane app ke upar install nahi hoga agar signature alag ho: pehle Backup Data, purani app uninstall, phir Restore.

Is zip mein kya hai
- v1.3: Har login par OTP. Password sahi hone ke baad 6 ank ka OTP phone ki SIM se
  Profile wale mobile number par SMS hota hai (5 minute valid, 3 galat koshish tak).
  OTP na aaye to "Security question se login" ka rasta hai. Profile mein OTP ON/OFF
  aur "Test SMS bhejo" button hai.
  Dhyan: SMS permission Allow karni hoti hai, SMS charge lag sakta hai, aur kai
  networks apne hi number par SMS deliver nahi karte (alag number daalo).
- v1.2: Login system (pehli baar account banao, phir password se login), Profile screen,
  upar teen-dot menu (Profile, History, Settings, Logout). Google Calendar Sync aur
  "Export to Phone Calendar" hata diye gaye.
  Login sirf is phone par save hota hai (cloud account nahi). Password bhool jao to
  security question se naya password bana sakte ho.
- v1.1: reminder ke time par ALARM bajta hai (lambi ringtone + vibration, max 3 minute),
  lock screen par Stop / 10 minute baad (Snooze) buttons aate hain.
- Alarms tab ka "Send Test" ab asli alarm bajata hai.
- app/src/main/assets/index.html  -> aapki oppo.html (bina badlav ke)
- Android code jo reminders ko phone ke AlarmManager mein lagata hai,
  isliye app band ho (recent apps se swipe) tab bhi notification aayegi.
  Phone restart ke baad bhi alarms apne aap wapas lag jaate hain.
- Bill JPG/PDF save (Downloads folder), WhatsApp image share, Backup/Restore
  file chooser - sab wrapper mein kaam karne ke liye joda hua hai.

APK banane ke 2 tareeke
-----------------------
A) Sirf phone se (PC nahi chahiye) - GitHub Actions
   1. github.com par free account banao, naya repository banao.
   2. Is zip ko extract karo, andar ka SAARA content (".github" folder samet)
      repository mein upload karo.
   3. Repository -> Actions tab -> "Build APK" chalne do (3-5 minute).
   4. Run khulne par neeche "Artifacts" mein MilkmanPRO-apk download karo,
      zip kholo, app-debug.apk install karo.

B) PC par Android Studio
   1. Android Studio kholo -> Open -> is folder ko chuno.
   2. Gradle sync hone do -> Build -> Build APK(s).

Phone mein zaroori settings (Oppo / ColorOS)
--------------------------------------------
1. Pehli baar app kholne par "Notifications Allow" dabao.
2. Battery wale popup mein "Settings kholo" -> Allow.
3. Settings -> Apps -> Milkman PRO -> Battery usage -> "Allow background activity"
   aur "Auto launch" ON karo. (Oppo ye settings aksar band rakhta hai.)
4. Alarms tab mein "Notifications ON" rakho aur "Send Test" se check karo.

Purana data
-----------
Browser wali app ka data is APK mein apne aap nahi aata. Purani app mein
Backup/Export karo, phir APK mein Restore Data se wapas lao.

Dhyan dein
----------
- Bill image / PDF aur fonts ke liye internet chahiye (html2canvas, jsPDF CDN se
  load hote hain, jaisa pehle tha).
- App band hone par notification ka text generic hota hai (jaise "Today's milk
  entry is pending"), kyunki tab app ka data check nahi hota. App khuli ho to
  woh sirf pending customers ke naam ke saath dikhata hai.
- Naya APK purane par install nahi hoga (signature alag). Pehle purani app mein Backup lo,
  purani app uninstall karo, phir naya install karke Restore Data karo.
- Ye debug-signed APK hai, apne use ke liye theek hai. Play Store ke liye alag
  release key se sign karna padega.
